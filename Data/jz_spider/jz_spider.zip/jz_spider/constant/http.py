


class HttpCode(object):
    success = 200
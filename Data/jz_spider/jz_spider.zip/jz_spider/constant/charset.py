
UTF8 = 'utf-8'
GB18030 = 'gb18030'
GBK = 'gbk'
BASE64='base64'